RewriteRule ^([a-z]+)$  _lugar de redireccion_

los corchetes permiten agarrar una lista de caracteres posibles


si se necesesita una misma url ocn un minimo cambio simplemente se agrega la parte entre parentesis (editar|eliminar)


en las url en vez de especificar toda la ruta, solo hay que colocar /lugar/


todos los recursos se tienen que manejar saliendo del directorio actual